# This file is deprecated and only provided for backward compatibility.
require 'rgl/transitivity'
